# Camino Spanish — Android APK Builder

This is an Android WebView app bundling the 50 Spanish lessons locally. No website or subscription is needed. Learning progress is stored on the device. Spanish speech depends on Android WebView speech synthesis support and installed voices.

## Build a real APK without installing Android Studio
1. Create a **private** GitHub repository.
2. Upload the **contents** of this project folder (including `.github/workflows/build-apk.yml`) to the repository. GitHub's web upload may hide dot-folders; verify `.github/workflows/build-apk.yml` is included.
3. In the repository, open **Actions** > **Build Android APK** > **Run workflow** (or wait for the push-triggered run).
4. After the run finishes, download the **Camino-Spanish-APK** artifact, extract it, and transfer `app-debug.apk` to your Android phone.
5. Open `app-debug.apk` and approve installation from that source if Android asks.

The APK is a debug-signed personal-use build, not a Play Store release. The workflow requires GitHub and internet access to compile. The course is offline once installed.

## Android Studio alternative
Open the project in Android Studio and choose Build > Build APK(s).
